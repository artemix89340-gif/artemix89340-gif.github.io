# Temple-of-Boom

Indiana explores an unknown cavern, claims the Orb, and then collects as much gold as possible and exits the cavern before it collapses. Indiana tries to find the shortest path to the Orb and maximizes gold collection in limited time using a recursive depth first search and Djisktra's shortest path algorithm.

I worked on Indiana.java, Heaps.Java,and Paths.java.Navigate to this by going to src->student, and you should be able 
to see the files.
